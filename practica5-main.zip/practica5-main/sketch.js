
function setup(){
  var canvas = createCanvas(1000,800);


}

function draw(){
background("salmon")

}
